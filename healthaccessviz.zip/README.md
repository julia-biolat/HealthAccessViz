# HealthAccessViz
A visualization project focused on analyzing and displaying healthcare accessibility across different regions, highlighting disparities and providing insights into population health characteristics.
