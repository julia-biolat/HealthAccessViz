import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, GeoJSON } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import './Map.scss';
import SIDO_MAP from './SIDO_MAP_2022.json';  // Ensure the path is correct
import * as d3 from 'd3';

const Map = () => {
  const [geoData, setGeoData] = useState(SIDO_MAP);
  const [populationData, setPopulationData] = useState({});

  useEffect(() => {
    d3.csv('/data/시도01-09.csv').then(data => {
      const population = {};

      data.forEach(row => {
        const region = row['행정기관'];
        const gender = row['성별'];
        const totalPopulation = Object.keys(row)
          .filter(key => key.includes('세'))
          .reduce((sum, key) => sum + parseInt(row[key], 10), 0);

        if (!population[region]) {
          population[region] = { 남: 0, 여: 0, total: 0 };
        }
        population[region][gender] += totalPopulation;
        population[region].total += totalPopulation;
      });

      setPopulationData(population);
    });
  }, []);

  const getColor = (d) => {
    return d > 1000000 ? '#800026' :
           d > 500000  ? '#BD0026' :
           d > 200000  ? '#E31A1C' :
           d > 100000  ? '#FC4E2A' :
           d > 50000   ? '#FD8D3C' :
           d > 20000   ? '#FEB24C' :
           d > 10000   ? '#FED976' :
                         '#FFEDA0';
  }

  const style = (feature) => {
    const region = feature.properties.CTP_KOR_NM;
    const population = populationData[region] ? populationData[region].total : 0;
    return {
      fillColor: getColor(population),
      weight: 2,
      opacity: 1,
      color: 'white',
      dashArray: '3',
      fillOpacity: 0.7
    };
  };

  return (
    <div className="map">
      <div className='button'>
        <button className='modebutton'>기존 방식</button>
        <button className='modebutton'>새로운 방식</button>
      </div>
      <MapContainer center={[36.5, 127.5]} zoom={7} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <GeoJSON data={geoData} style={style} />
      </MapContainer>
    </div>
  );
};

export default Map;
