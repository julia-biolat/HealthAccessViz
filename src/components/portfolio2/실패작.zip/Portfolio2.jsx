import { useRef, useState, useEffect, useCallback } from "react";
import "./portfolio2.scss";
import { motion, useScroll, useSpring } from "framer-motion";
import SliderAge from './SliderAge';
import RegionSelector from './RegionSelector';
import DiseaseSelector from './DiseaseSelector';
import { MapContainer, TileLayer, GeoJSON, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import * as d3 from 'd3';
import L from 'leaflet';
import SIDO_MAP from './SIDO_MAP_2022.json';

const ageGroups = ["0~9세", "10~19세", "20~29세", "30~39세", "40~49세", "50~59세", "60~69세", "70~79세", "80~89세", "90~99세", "100세 이상"];

const Portfolio2 = () => {
  const ref = useRef();

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["end end", "start start"],
  });

  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
  });

  const [selectedRegion, setSelectedRegion] = useState([]);
  const [selectedDiseases, setSelectedDiseases] = useState([]);
  const [correspondingSubjects, setCorrespondingSubjects] = useState({});
  const [selectedAgeGroup, setSelectedAgeGroup] = useState(null);
  const [hospitalData, setHospitalData] = useState({});
  const [populationData, setPopulationData] = useState({});
  const [trigger, setTrigger] = useState(0);
  const dataLoaded = useRef(false);

  useEffect(() => {
    if (!dataLoaded.current) {
      // 병원 데이터 로드
      d3.csv('/data/hospital_data.csv').then(data => {
        const hospitalCounts = {};
        data.forEach(row => {
          const region = row['지역'];
          const subject = row['진료과목'];
          const count = parseInt(row['병원수'], 10);
          if (!hospitalCounts[region]) {
            hospitalCounts[region] = {};
          }
          hospitalCounts[region][subject] = count;
        });
        setHospitalData(hospitalCounts);
      }).catch(error => console.error('Error loading hospital data:', error));

      // 인구 데이터 로드
      d3.csv('/data/시도01-09.csv').then(data => {
        const population = {};
        data.forEach(row => {
          const region = row['행정기관'];
          population[region] = {};
          ageGroups.forEach(ageGroup => {
            population[region][ageGroup] = parseInt(row[ageGroup], 10) || 0;
          });
        });
        setPopulationData(population);
        dataLoaded.current = true;
      }).catch(error => console.error('Error loading population data:', error));
    }
  }, []);

  const getColor = useCallback((value, min, max) => {
    const ratio = (value - min) / (max - min);
    return `rgba(${255 * (1 - ratio)}, ${255 * ratio}, 0, 1)`;
  }, []);

  const styleOldMethod = useCallback((feature) => {
    const region = feature.properties.CTP_KOR_NM;
    if (!selectedRegion.includes(region)) {
      return {
        fillColor: '#d3d3d3', // Default color for non-selected regions
        weight: 2,
        opacity: 1,
        color: 'white',
        dashArray: '3',
        fillOpacity: 0.7
      };
    }

    let totalHospitalCount = 0;
    let totalPopulation = 0;

    if (hospitalData[region]) {
      totalHospitalCount = Object.values(hospitalData[region]).reduce((a, b) => a + b, 0);
    }
    if (populationData[region]) {
      totalPopulation = Object.values(populationData[region]).reduce((a, b) => a + b, 0);
    }

    const value = totalHospitalCount / totalPopulation || 0;
    const minHospitalDensity = Math.min(...Object.values(hospitalData).map(regionData => {
      const totalHospitals = Object.values(regionData).reduce((a, b) => a + b, 0);
      const regionPop = Object.values(populationData).reduce((a, b) => a + b, 0);
      return totalHospitals / regionPop || 0;
    }));
    const maxHospitalDensity = Math.max(...Object.values(hospitalData).map(regionData => {
      const totalHospitals = Object.values(regionData).reduce((a, b) => a + b, 0);
      const regionPop = Object.values(populationData).reduce((a, b) => a + b, 0);
      return totalHospitals / regionPop || 0;
    }));

    return {
      fillColor: getColor(value, minHospitalDensity, maxHospitalDensity),
      weight: 2,
      opacity: 1,
      color: 'white',
      dashArray: '3',
      fillOpacity: 0.7
    };
  }, [selectedRegion, hospitalData, populationData, getColor]);

  const styleRefinedMethod = useCallback((feature) => {
    const region = feature.properties.CTP_KOR_NM;
    if (!selectedRegion.includes(region)) {
      return {
        fillColor: '#d3d3d3', // Default color for non-selected regions
        weight: 2,
        opacity: 1,
        color: 'white',
        dashArray: '3',
        fillOpacity: 0.7
      };
    }

    let totalHospitalCount = 0;
    let targetPopulation = 0;

    selectedDiseases.forEach(disease => {
      const subject = correspondingSubjects[disease];
      if (hospitalData[region] && hospitalData[region][subject]) {
        totalHospitalCount += hospitalData[region][subject];
      }
    });

    if (populationData[region] && selectedAgeGroup) {
      targetPopulation = populationData[region][selectedAgeGroup];
    }

    const value = totalHospitalCount / targetPopulation || 0;
    const minHospitalDensity = Math.min(...Object.values(hospitalData).flatMap(regionData => {
      return selectedDiseases.map(disease => {
        const subject = correspondingSubjects[disease];
        const count = regionData[subject] || 0;
        return count / (populationData[region] && populationData[region][selectedAgeGroup] || 1);
      });
    }));
    const maxHospitalDensity = Math.max(...Object.values(hospitalData).flatMap(regionData => {
      return selectedDiseases.map(disease => {
        const subject = correspondingSubjects[disease];
        const count = regionData[subject] || 0;
        return count / (populationData[region] && populationData[region][selectedAgeGroup] || 1);
      });
    }));

    return {
      fillColor: getColor(value, minHospitalDensity, maxHospitalDensity),
      weight: 2,
      opacity: 1,
      color: 'white',
      dashArray: '3',
      fillOpacity: 0.7
    };
  }, [selectedRegion, selectedDiseases, correspondingSubjects, hospitalData, populationData, selectedAgeGroup, getColor]);

  useEffect(() => {
    if (selectedDiseases.length > 0 || selectedAgeGroup !== null) {
      setTrigger(trigger => trigger + 1);
    }
  }, [selectedDiseases, selectedAgeGroup]);

  const Legend = ({ min, max, title }) => {
    const map = useMap();

    useEffect(() => {
      if (map && min !== max) {
        const legend = L.control({ position: 'bottomright' });

        legend.onAdd = () => {
          const div = L.DomUtil.create('div', 'info legend');
          const grades = [min, (min + max) / 4, (min + max) / 2, ((min + max) * 3) / 4, max];
          const labels = [];

          div.innerHTML += `<h4>${title}</h4>`;
          for (let i = 0; i < grades.length; i++) {
            div.innerHTML +=
              '<i style="background:' + getColor(grades[i], min, max) + '; width: 18px; height: 18px; display: inline-block; margin-right: 8px;"></i> ' +
              '<span style="color:black;">' + grades[i].toFixed(0) + (grades[i + 1] ? '&ndash;' + grades[i + 1].toFixed(0) + '</span><br>' : '+</span>');
          }

          div.style.backgroundColor = 'white';
          div.style.padding = '10px';
          div.style.borderRadius = '5px';
          div.style.boxShadow = '0 0 15px rgba(0, 0, 0, 0.2)';

          return div;
        };

        legend.addTo(map);
        return () => {
          legend.remove();
        };
      }
    }, [map, min, max, title, getColor]);

    return null;
  };

  const minHospitalDensityOld = Math.min(...Object.values(hospitalData).map(regionData => {
    const totalHospitals = Object.values(regionData).reduce((a, b) => a + b, 0);
    const regionPop = Object.values(populationData).reduce((a, b) => a + b, 0);
    return totalHospitals / regionPop || 0;
  }));

  const maxHospitalDensityOld = Math.max(...Object.values(hospitalData).map(regionData => {
    const totalHospitals = Object.values(regionData).reduce((a, b) => a + b, 0);
    const regionPop = Object.values(populationData).reduce((a, b) => a + b, 0);
    return totalHospitals / regionPop || 0;
  }));

  const minHospitalDensityRefined = Math.min(...Object.values(hospitalData).flatMap(regionData => {
    return selectedDiseases.map(disease => {
      const subject = correspondingSubjects[disease];
      const count = regionData[subject] || 0;
      return count / (populationData[selectedAgeGroup] || 1);
    });
  }));

  const maxHospitalDensityRefined = Math.max(...Object.values(hospitalData).flatMap(regionData => {
    return selectedDiseases.map(disease => {
      const subject = correspondingSubjects[disease];
      const count = regionData[subject] || 0;
      return count / (populationData[selectedAgeGroup] || 1);
    });
  }));

  return (
    <div className="portfolio" ref={ref}>
      <div className="progress">
        <h1 className="jua-regular">의료 접근성 분석</h1>
        <motion.div style={{ scaleX }} className="progressBar"></motion.div>
      </div>
      <section className="content-section">
        <div className="container">
          <div className="wrapper">
            <motion.div className="text-container">
              인구 특성을 고려하느냐 안 하느냐는 의료 접근성 지수 평가에 매우 중요한 요소이다.
            </motion.div>
            <div className="Controller">
              <SliderAge onAgeGroupChange={setSelectedAgeGroup} />
              <RegionSelector onRegionChange={setSelectedRegion} />
              <DiseaseSelector onDiseaseChange={(diseases, subjects) => {
                setSelectedDiseases(diseases);
                setCorrespondingSubjects(subjects);
              }} />
            </div>
            <div className="maps-container">
              <div className="map-wrapper">
                <h4>Choropleth Map (Refined Method)</h4>
                <MapContainer center={[36.5, 127.5]} zoom={7} className="leaflet-container" id="map-refined">
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  <GeoJSON
                    key={`refined-${trigger}`}
                    data={SIDO_MAP}
                    style={styleRefinedMethod}
                  />
                  <Legend min={minHospitalDensityRefined} max={maxHospitalDensityRefined} title="Hospital Density (Refined)" />
                </MapContainer>
              </div>
              <div className="map-wrapper">
                <h4>Choropleth Map (Old Method)</h4>
                <MapContainer center={[36.5, 127.5]} zoom={7} className="leaflet-container" id="map-old">
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  <GeoJSON
                    key={`old-${trigger}`}
                    data={SIDO_MAP}
                    style={styleOldMethod}
                  />
                  <Legend min={minHospitalDensityOld} max={maxHospitalDensityOld} title="Hospital Density (Old)" />
                </MapContainer>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Portfolio2;
